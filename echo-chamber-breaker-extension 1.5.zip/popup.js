document.addEventListener("DOMContentLoaded", function () {
  const status = document.getElementById("status");

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs || !tabs[0]) {
      status.textContent = "Could not access the current tab.";
      return;
    }

    chrome.scripting.executeScript(
      {
        target: { tabId: tabs[0].id },
        func: () => window.detectedBias || "Bias not available"
      },
      (results) => {
        if (chrome.runtime.lastError) {
          status.textContent = "Error: " + chrome.runtime.lastError.message;
          return;
        }

        const result = results[0]?.result || "No result returned.";
        status.textContent = result;
      }
    );
  });
});
