// content.js

console.log("Content script is running...");

const pageText = document.body.textContent.toLowerCase(); // Lowercase for easier analysis
console.log("Page Text:", pageText);

// Weighted keywords for better accuracy (more granular context)
const weightedKeywordsLeft = {
  "green new deal": 3,
  "tax the rich": 2,
  "feminism": 1,
  "lgbtq+ rights": 2,
  "climate change": 2,
  "intersectionality": 2,
  "socialism": 3,
  "black lives matter": 2,
  "medicare for all": 3,
  "universal healthcare": 2,
  "racial justice": 2,
  "student debt relief": 2,
  "progressive": 1,
  "abortion rights": 2,
  "love": 1, // Added "love" to left-leaning due to associations with progressive causes
};

const weightedKeywordsRight = {
  "maga": 3,
  "tax cuts": 2,
  "gun rights": 2,
  "border wall": 3,
  "religious freedom": 2,
  "conservative": 1,
  "small government": 2,
  "patriot": 2,
  "traditional values": 2,
  "pro life": 2,
  "capitalism": 1,
  "second amendment": 2,
  "war": 2,
  "violence": 3,
  "blood": 3,
  "kill": 3,
  "harm": 2,
  "battle": 2, // Added "battle" as it often relates to right-leaning discussions
  "combat": 2, // Added "combat" similarly to "battle"
};

const disturbingGroups = {
  violence: ["kill", "murder", "blood", "gore", "harm", "behead", "execute", "shooting", "assault"],
  abuse: ["assault", "abuse", "rape", "molest", "harass"],
  extremism: ["terror", "torture", "radical", "extremist", "militant", "jihad"],
};

function weightedCount(text, weightedWords) {
  let score = 0;
  for (let word in weightedWords) {
    if (text.includes(word)) {
      score += weightedWords[word];
    }
  }
  return score;
}

// Advanced sentiment analysis (e.g., using sentiment library or custom rules)
function detectBias(text) {
  const wordCount = text.split(/\s+/).length;

  // Calculate weighted scores
  const leftScore = weightedCount(text, weightedKeywordsLeft);
  const rightScore = weightedCount(text, weightedKeywordsRight);

  let disturbingCount = 0;
  const flags = [];

  // Check for disturbing content groups (violence, abuse, extremism)
  for (let category in disturbingGroups) {
    for (let word of disturbingGroups[category]) {
      if (text.includes(word)) {
        disturbingCount++;
        flags.push(category);
        break;
      }
    }
  }

  let bias = "Neutral or Mixed";
  let confidence = 0;

  // Adjust bias based on scores
  if (leftScore > rightScore) {
    bias = "Left-leaning";
    confidence = ((leftScore - rightScore) / wordCount * 1000).toFixed(2);
  } else if (rightScore > leftScore) {
    bias = "Right-leaning";
    confidence = ((rightScore - leftScore) / wordCount * 1000).toFixed(2);
  }

  // Append disturbing content flags
  if (disturbingCount > 0) {
    bias += ` | ⚠️ Disturbing content (${flags.join(", ")})`;
  }

  return { bias, confidence, flags };
}

// Running the bias detection on page text
const { bias, confidence, flags } = detectBias(pageText);
console.log("Detected Bias:", bias);
window.detectedBias = bias;

// Display bias on the page (overlay)
function showBiasOverlay(bias, confidence, flags) {
  const overlay = document.createElement('div');
  overlay.innerHTML = `
    <strong>🧠 Bias Detected: ${bias}</strong><br>
    Confidence: ${confidence}%<br>
    Flags: ${flags.join(', ')}`;
  overlay.style.cssText = `
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: rgba(0,0,0,0.8);
    color: white;
    padding: 10px 14px;
    border-radius: 8px;
    font-family: sans-serif;
    font-size: 14px;
    z-index: 9999;
  `;
  document.body.appendChild(overlay);
}

showBiasOverlay(bias, confidence, flags);